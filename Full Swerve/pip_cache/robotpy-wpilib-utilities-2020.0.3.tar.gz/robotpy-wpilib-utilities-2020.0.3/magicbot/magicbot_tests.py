from robotpy_ext.autonomous.selector_tests import *
